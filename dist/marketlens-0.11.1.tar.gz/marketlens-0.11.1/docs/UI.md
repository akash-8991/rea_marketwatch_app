# Interface guide

One interface, three channels (desktop server, container, Android app): `src/marketlens/static/`. No framework and no build step at install time.

## Stack and why
| Layer | Choice | Notes |
|---|---|---|
| Components | shadcn/ui **design system** re-implemented in `static/js/ui.js` | Same variants (default, secondary, outline, ghost, destructive, link), badges, alerts, tabs, dialog, toasts, dropdown, skeleton, command palette. Not the React package; see [THIRD_PARTY.md](THIRD_PARTY.md) for the reasoning and the migration path. |
| Styling | Tailwind CSS v4 utilities (generated, `css/tailwind.css`, ~13 KB, ~3 KB compressed) over the tokens in `css/style.css` | The generated file is committed; `cd ui && npm run build` regenerates it and CI checks it is current. |
| Icons | Lucide, 58 icons as inline SVG (`js/icons.js`) | stroke is `currentColor`, so icons follow theme and text colour. |
| Charts | one hand-written SVG chart (`js/chart.js`), no library | smaller than any charting dependency; decimates to ~600 points, keeps every peak and trough. |
| Theming | light and dark through CSS variables; `Toggle` in the top bar | contrast of every token pair is recomputed in `tests/test_design.py`. |

## Layout
Top bar (menu on phones, logo, search box that opens the palette, market/data status pill, user, theme) above a left navigation rail with icons. On phones the rail
slides in over a dimmed page, starts below the status bar, and closes on selection. The first screen reserves its space (skeletons, fixed heights) so nothing jumps.

### Screen sizes
The layout is fluid and works from a 280 px folded phone to a 4K display, in portrait and landscape, light and dark.

| Width | What changes |
|---|---|
| ≤ 340 px | status pill hides (the Live/Closed state is also in the tab title of the pill on wider screens); search trigger shrinks to an icon |
| ≤ 380 px | smaller gutters and base font, narrower menu |
| ≤ 640 px | sign-out becomes an icon, index tiles scroll sideways instead of wrapping, tighter cards and table cells |
| ≤ 860 px | navigation rail becomes a slide-in menu (with the signed-in user at its foot) |
| ≤ 1100 px | narrower rail, user name leaves the top bar |
| ≥ 1500 px / ≥ 2200 px | content centred with a wider maximum; larger base font and rail on very large displays |
| landscape, ≤ 520 px high | slimmer top bar, shorter charts |

Rules that make it hold: grid and flex children may shrink (`min-width: 0`), so a wide table scrolls inside its own box and can never stretch the page;
grid minimums use `min(100%, …)`; charts size to the window height; dialogs and toasts never exceed the viewport; touch screens get 44 px targets
(including sort buttons and stars); pinch-zoom is never disabled.

**Checking it:** `tests/test_design.py` guards these rules. For a visual sweep, serve `mobile/www`, load `mobile/dev/browser-mock.js` then
`mobile/dev/layout-check.js`, set the window size and run `await __layoutCheck(['#/', '#/markets', '#/screener', '#/options', '#/watchlist', '#/paper', '#/news', '#/updates', '#/quote/INFY'])`.
It reports sideways page growth, elements poking out of the window, wrapping controls, clipped text, overlapping top-bar items and small tap targets.
Last run at 280, 320, 390, 667×375, 768, 1024 and 1920 px: no findings (the only reports left are headlines that wrap onto several lines, which is intended).

## Terminal theme and chrome
The default theme is **Terminal**: black panels, amber labels and headings, monospace figures, dense tables with zebra rows, square corners, white-on-black data with green and red for direction (every colour pair is checked for WCAG AA contrast in `tests/test_design.py`). **Dark** and **Light** remain; the top-bar button cycles the three and Settings has a selector (the preference moved everyone to Terminal once, after that the choice is theirs).
Chrome: an IST clock, a scrolling **ticker tape** of the indices and the most traded stocks (painted by the live feed, pauses on hover), and a **function-key bar** along the bottom (Alt + 1 to 9, 0, - and = open Home, Markets, Charts, Screener, Options, Watchlist, Paper, Signals, Orders, Fundamentals, Operator, Settings; F-keys themselves are left to the browser). The search box is a **command line**: besides symbols and company names it understands mnemonics: `INFY GP` (graph) chart, `INFY DES` or `EQ` stock page, `INFY FA` analysis, `INFY N` news, `INFY OPT`, `INFY SIG` signals, and one-word commands `TOP`, `MKT`, `SCRN`, `WATCH`, `PAPER`, `SIG`, `ORD`, `OPS`, `FUND`, `SET`, `NEWS`. On phones the tape and menu stay, the clock and function-key bar are hidden.

## Signals, Orders & risk, Operator, Fundamentals, Settings
The **Operator** page has a **Latency** tab (p50, p95, p99, max against the 1 ms budget for the in-process stages, network and page stages listed without a budget, and a 2,000-run benchmark button; see [LATENCY.md](LATENCY.md)). The **Signals** page shows the ten-year backtest gate before any trade. See [DESK.md](DESK.md) for what each does and how it maps to the requirements, and [BROKER.md](BROKER.md) for the Zerodha connection.
* **Fundamentals** screens (`fund-screens.js`): dividend income, steady dividend payers, yield above sector, near the 52-week low while paying, leaders near the high, beaten down but steady, and a composite scorecard (value 30, income 25, momentum 25, liquidity 20; missing components are skipped, not guessed), plus sector P/E, P/B and yield against the Nifty 50.

## Live refresh (every 100 ms)
While the market trades, every screen repaints within 100 ms of new data: the index tiles, the sector heat map and every stock price and change that is on screen (rows scrolled far out of view are
left out). One small request (`/api/live`) carries all of it; requests never overlap, the page pauses while its tab is hidden, backs off when the server struggles, and slows to every
30 s when the market is shut (the first request after the open switches it back). A value that changed flashes green (up) or red (down) for a moment (not when the system asks for reduced motion).
The top banner ("Market open · last refresh…") is gone; the status pill in the top bar carries the state (Live, Market closed, Stale, Delayed, Disconnected) and its tooltip has the detail and the time of the last update.
The page asks the server every 100 ms and repaints only what changed; the server answers from memory, reuses an NSE quote for up to a second and spends at most 10 NSE stock-quote calls a second in total, so a long list is refreshed proportionally less often rather than with more requests; the
home page, Markets, the stock page, the watchlist and Chart analysis all use the same feed.

## New on NSE
A card at the bottom of the home page lists equities that listed in the last 45 days and ones listing within a week (newest first, with listing date, "Lists tomorrow / Listed today / N days ago", and a live price and change). It is built from NSE's own list of every listed equity (`EQUITY_L.csv`, about 2,600 stocks with listing dates), downloaded every 6 hours and kept in the database, so a company that listed today is found by search, opens a stock page and appears here without waiting for NSE Indices to add it to the Nifty Total Market list (which has about 750 stocks and changes only at index rebalancing). Such a stock has the industry "Unclassified": no sector tile and no peer group until the index includes it. The desktop package ships a snapshot as the starting point; the phone app downloads it at first start and keeps it.

## Chart analysis
`#/chart/<SYMBOL or index key>` (also **Charts** in the menu, a **Chart analysis** button on every stock page, and the command palette). Candle sizes: 5 min, 15 min, hourly, daily, weekly, monthly, yearly, chosen with the same underlined tabs as the other pages.
* **Picker**: one searchable list for **stocks and indices** (a button showing the current choice opens a list with a search box; empty it shows recent choices, the main indices and the most traded stocks; typing filters indices and searches stocks; arrow keys, Enter and Escape work; indices carry an Index tag). An index is addressed as `IDX_<NAME>` (for example `IDX_NIFTY_BANK`), so `#/chart/IDX_NIFTY_50` opens Nifty 50. Index daily history comes from NSE's index history (up to 12 months a call); index intraday candles are recorded from the live feed like stocks (headline and sector indices always, others while their chart is open).
* **Data**: daily candles come from NSE's daily history (open, high, low, close, volume, as far back as NSE provides); weekly, monthly and yearly candles are built from them. NSE's servers keep **no intraday
  history**, so 5 min, 15 min and hourly candles come from **Yahoo Finance's public chart endpoint** (the provider the news headlines already use; `SYMBOL.NS` for stocks and a Yahoo ticker for about 20 NSE indices: 30 days of 5-minute,
  60 days of 15-minute and about two years of hourly candles, aligned to the 9:15 open, possibly a few minutes behind the exchange), joined to the one-minute bars MarketLens records itself while it is open (kept 5 days)
  for anything newer. If Yahoo cannot be reached, offline mode is on, or an index has no Yahoo ticker, only the recorded bars are used and the page says so. While the market is live the last candle moves with every price update.
* **Overlays and panels** are small toggle chips in two labelled rows (Overlays, Panels), tight on desktop and larger on touch screens. Overlays: EMA 9/21, SMA 20/50/200, Bollinger bands, Supertrend, VWAP (intraday), support and resistance (swing points clustered by touches), classic pivot points, Fibonacci retracement of the last swing.
* **Panels**: volume, RSI, MACD (with histogram), stochastic, ADX with +DI and -DI. Drag to pan, + and - to zoom (Ctrl or Cmd with the wheel), arrow keys when the chart has focus; a crosshair tooltip shows open, high, low, close, change, volume and the indicator values.
* **Technical read**: a verdict (strongly bullish to strongly bearish) from weighted signals across trend (price against EMA 21, SMA 50 and 200, EMA 9 against 21, golden or death cross state, Supertrend, ADX),
  momentum (RSI, MACD, stochastic, 10-candle change), volatility (Bollinger position), volume (VWAP, high-volume candles) and patterns; every signal is listed with its reason. Key levels, pivots, Fibonacci levels,
  candlestick patterns (doji, hammer, hanging man, shooting star, inverted hammer, marubozu, engulfing, harami, piercing line, dark cloud cover, morning and evening star, three white soldiers, three black crows)
  and chart patterns (higher highs and lows or the reverse, double top and bottom, range breakout and breakdown).
Maths is in `ta.js`, intraday history in `yahoo.py` / `yahoo.js`, recording in `ticks.py` / `ticks.js`, the page in `chart-view.js`; all are unit-tested.

## Keyboard
| Keys | Does |
|---|---|
| `Ctrl/Cmd + K`, or `/` outside a text field | open the command palette |
| `↑ ↓ Home End`, `Enter`, `Esc` in the palette | move, open, close |
| `← →` (and `Shift` for 10 days) on the chart | move the crosshair; `Esc` hides it |
| `← → Home End` on any tab strip | switch tab |
| `↑ ↓ Esc` in menus | move, close |
All controls have visible focus rings; dialogs trap focus and restore it; reduced-motion preferences switch animation off; touch devices get 44 px targets.

## Data status, never by colour alone
| Badge | Meaning |
|---|---|
| ● **Live** | market open and the latest NSE price is under 5 minutes old |
| ◷ **Delayed** | market open, price older than 5 minutes |
| ☾ **Closed** | market shut: the last update of the day is shown |
| ⚠ **Stale** | NSE could not be reached; a saved copy is shown (also announced in a toast) |
| ✕ **Unavailable** | no data for this symbol, with the reason beside it |
| ⛁ **Cached** | a row that is being added and has not been fetched yet |
Green, red and a muted blue-grey (unchanged) carry direction; every one also has an arrow, a sign or a word.

## Watchlist
Add by symbol (suggestions from the stock list), remove with **Undo**, sort by symbol, price, change ₹, change % or last update (unavailable rows always last), filter
by positive, negative, unchanged, stale or unavailable, search within the list, refresh one row or all, and choose auto-refresh (1, 5, 15, 30 or 60 s; off pauses it;
it also pauses while the browser tab is hidden and refreshes the moment you return). Rows are also updated in place by the live feed (every 100 ms, only when a row's numbers changed). NSE itself states about one update a minute: the app asks every 100 ms, an NSE quote is reused for at most one second server-side (within a fixed budget of NSE calls), so a change shows within about a second of NSE publishing it; "Refresh" buttons bypass the cache, but at most once per symbol every 5 seconds. Adds and removes are applied
at once and rolled back if NSE rejects the symbol. Lists over 300 rows are windowed (about 40 rows in the page at a time); measured: 1,000 rows took 162 ms to lay
out, so a plain 50-row list is left as is.

## Stock page
The price header comes from one lean request (`/api/quote/<symbol>`): company, industry, exchange, price, change in ₹ and %, last-trade time and its age, source, status
badge, refresh and watchlist buttons. The chart and the detail tabs load independently below it. Chart ranges: 1D (honestly unavailable: NSE's servers have daily data
only), 1W, 1M, 3M, 6M, 1Y (the API still accepts 5Y and 10Y, which the strategy lab uses for all of NSE's history; a saved 5Y or 10Y choice from an older version falls back to 3M). NSE's daily history goes back as far as the data source returns (several years for most stocks). Each range is fetched once, cached, and
a request that is no longer wanted (you switched range) is cancelled.

## Paper trading
Four tabs, in the same underlined style as the Screener and the stock page.
* **Portfolio**: value, profit and loss, cash, invested, realised and unrealised result, fees paid; allocation bar; positions (average cost includes the buying fee); trade
  history with CSV download (spreadsheet formulas neutralised); reset with confirmation.
* **Trade**: order ticket with a live price card, quantity shortcuts (10, 25, 50 percent, max), an itemised cost, and reasons when an order cannot be placed. The fill price
  is fetched at the moment you press the button. Orders are blocked when there is no current price. Rules: whole shares, long only (no short selling), no borrowing, a 0.10% fee per trade.
* **Stock strategies**: 65 strategies, in twelve groups, run over a stock's real daily history. Choose a strategy, a stock, a period, costs and the strategy's own settings. Output:
  final value against buy and hold, worst fall, closed trades and win rate, time invested, costs, an account-value curve for both, every trade, today's position with one-click
  paper trades, and a table of every strategy on the same data. Each has a plain-language page: the idea, when it buys and sells, when it works, when it struggles, what to learn.
  A signal is read at one close and acts at the next; the strategies use closing prices only (highs and lows are not in the saved history), so oscillators use the closing range.
* **Option strategies**: 41 strategies built from the real option chain (see below).

Strategy pages (the description, the legs and the comparison tables) use a smaller type size, and long strategy names and explanations wrap inside their cell instead of widening the table; figures never wrap.

### Stock and technical-analysis strategies
| Group | Strategies |
|---|---|
| Benchmark | Buy and hold |
| Trend following (15) | Moving-average crossover, EMA crossover, triple moving-average alignment, golden / death cross, price above its average, MACD signal crossover, MACD above zero, linear-regression trend, TRIX, **Supertrend, ADX and directional movement, Parabolic SAR, Ichimoku cloud, Aroon, Heikin-Ashi trend** |
| Momentum (9) | Momentum, RSI above 50, RSI momentum band, stochastic, CCI, time-series momentum, near the 52-week high, **Williams %R, Elder ray** |
| Mean reversion (8) | RSI reversion, RSI(2) pullback, Bollinger reversion, Z-score, dip below the average, consecutive down days, **Keltner channel reversion, gap-down rebound** |
| Pullback (1) | **Fibonacci pullback in an uptrend** |
| Breakout and volatility (11) | Donchian, Turtle 55/20, Bollinger breakout, volatility squeeze, **Keltner breakout, TTM squeeze, gap-up continuation, inside-bar breakout, NR7 breakout, pivot-point breakout, consolidation range breakout** |
| Volume (4) | **Money Flow Index, Chaikin money flow, on-balance volume trend, high-volume breakout** |
| Candlestick patterns (4) | **Bullish reversals (hammer, engulfing, morning star, piercing line, three white soldiers, harami), engulfing long and short, morning and evening stars, hammer and shooting star** |
| Risk rules (3) | Trailing stop, stop-loss with profit target, **Chandelier exit** |
| Investing, Calendar | Monthly SIP; turn of the month; Halloween |
| Long and short (6) | Moving-average crossover, MACD, momentum, channel breakout, Bollinger reversion, RSI reversion, each also selling short |

The bold ones need highs, lows, opens or volume: the lab now passes the full daily candle (open, high, low, close, volume) to every strategy; a history without opens, highs and lows falls back to flat candles (close only). Fundamental strategies cannot be backtested honestly (NSE publishes no point-in-time financials), so they are screens on the Fundamentals page instead.

Short strategies sell borrowed shares and buy them back (a short can lose without limit). The paper *account* still cannot short; shorting is simulated only inside the strategy lab.
Every setting is clamped to a safe range, so a typo cannot crash or distort a run.

### Option strategies
Pick an underlying (NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY or any stock that has option data), an expiry, a strategy, a strike gap (how far apart the legs sit), lots and lot
size. The legs are placed on real strikes of the chain from `/api/options` and priced from each contract's last traded price in NSE's latest end-of-day file (a missing price is
estimated with Black-Scholes and flagged). Output: legs table, net debit or credit, maximum profit and loss (or "unlimited"), break-evens, reward to risk, a model estimate of
the chance of profit, net delta, daily time decay and vega, a profit-and-loss chart (at expiry, and "if closed today"), a what-if price box, and a table of every strategy
on the same chain. **Save to my paper option book** keeps a position (separate from the share portfolio; premiums are pretend); it is marked to the latest chain, can be closed
at current premiums, or settled at an entered price after expiry.

| Group | Strategies |
|---|---|
| Single position | Long underlying, short underlying (benchmarks), long call, long put, short call, cash-secured put |
| Vertical spreads | Bull call, bear put, bull put (credit), bear call (credit), bullish and bearish risk reversal |
| Synthetic | Synthetic long, synthetic short |
| Income and hedging | Covered call, protective put, collar, covered put, covered strangle |
| Volatility | Long straddle, long strangle, strap, strip, long guts, call and put ratio backspreads, reverse iron condor, reverse iron butterfly |
| Range and income | Short straddle, short strangle, iron condor, iron butterfly, call / put butterfly, call condor, broken-wing butterfly, call and put ratio spreads, jade lizard |
| Time spreads | Long calendar spread, diagonal spread (need the next expiry's chain) |

What is exact and what is modelled: the profit and loss at expiry is arithmetic on the chain premiums. "If closed today", the Greeks and the chance of profit use Black-Scholes
(7% interest, no dividends, each contract's implied volatility) and a lognormal price model: shapes to learn from, not forecasts. Brokerage, taxes, margin and early assignment are
not modelled, and lot sizes are editable defaults (NSE revises them). The lab never places an order anywhere. Unlimited-risk strategies carry a warning.


How the simulation stays honest: a signal is read from data up to and including a day and acts at the **next day's** close (no peeking, tested); all in or all out in whole
shares; the same fee (default 0.10%) and slippage (0.05%) on every trade; results compared with buying on day one and holding. Past results of a rule on one stock's
history are a way to understand the rule, not a forecast, and only 2.8 years of NSE history exist, which is short for any strategy.
The account is stored in this browser or app only (per signed-in user) under `ml.paper`; clearing the app's storage removes it.

## Files
`ui.js` components and toasts · `palette.js` command palette · `dashboard.js` watchlist · `chart.js` price chart · `paper-view.js` paper-trading page · `options-view.js` option strategies tab · `desk-core.js` desk rules · `desk.js` desk runtime · `signals-view.js` `orders-view.js` `ops-view.js` `fundamentals-view.js` `settings-view.js` desk pages · `theme.js` themes · `listings.js` New on NSE card · `chart-view.js` chart analysis page · `ta.js` technical analysis maths · `live.js` the one-second feed · `options-lab.js` option maths and catalogue paper trading page ·
`paper.js` account rules · `strategies.js`, `indicators.js` simulator · `pure.js` testable logic (sorting, filtering, windowing, decimation, highlighting) ·
`lib.js` helpers and API client (timeouts, retries with backoff and jitter, cancellation) · `icons.js` generated icons.

## Market updates and the Economy category
The **Market updates** page (`#/updates`) has the tabs All, Markets, Stocks, Trends and Economy. The first three are generated from the NSE data (index valuation lines are in Markets). **Economy** is live headlines from `GET /api/news/economy` (Google News queries kept only when the headline matches an economy topic): central bank and rates, GDP and growth, PMI and activity, inflation, external sector (current account deficit CAD, CAS, forex reserves), exports and imports, tax, budget and fiscal, jobs, and demand and credit. Each headline carries its topic badges, and the chips above the list filter by topic. A headline can belong to several topics. CAD and CAS count only when written in capitals. The topic table is `ECONOMY_TOPICS` in `analysis.py` and `analysis.js`, and `tests/test_economy.py` and `mobile/tests/economy.test.mjs` run the same headlines through both. The All tab shows the top six economy headlines under the generated updates.
